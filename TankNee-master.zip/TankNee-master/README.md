
<h1 align="center">👋 Hi, I'm TankNee</h1>

### 📌 Social Profile 

[![jikeFollowers](https://img.shields.io/badge/dynamic/json?color=%23FFE411&label=JikeFollowers&query=%24.data.totalSubs&url=https%3A%2F%2Fapi.spencerwoo.com%2Fsubstats%2F%3Fsource%3DjikeFollower%26queryKey%3Dd25cf3f3-f6e6-4427-b418-51ba06cf26e9)](https://m.okjike.com)
[![jikeLikes](https://img.shields.io/badge/dynamic/json?color=%23FFE411&label=JikeLikes&query=%24.data.totalSubs&url=https%3A%2F%2Fapi.spencerwoo.com%2Fsubstats%2F%3Fsource%3DjikeLiked%26queryKey%3Dd25cf3f3-f6e6-4427-b418-51ba06cf26e9)](https://m.okjike.com)
[![WeiboFans](https://img.shields.io/badge/dynamic/json?color=%23E6162D&label=WeiboFollowers&query=%24.data.totalSubs&url=https%3A%2F%2Fapi.spencerwoo.com%2Fsubstats%2F%3Fsource%3Dweibo%26queryKey%3D5201023153)](https://www.weibo.com)
![](https://visitor-badge.glitch.me/badge?page_id=TankNee.TankNee)

---

<a href="https://github.com/linonetwo">
    <p align="center">
        <img src="https://github-profile-trophy.vercel.app/?username=TankNee&column=7&theme=onedark"/>
    </p>
</a>

### 👦 About Me 

- 🌱 A rookie javascript developer.
- 📫 You could contact with me by [email](mailto:nee@tanknee.cn) or put a comment in my web site!
-  ⚡  Fun fact: It has been three year that I start to code and join github!
- 🎉 If possible , you could look up my current activities in my [blog](https://www.tanknee.cn)!
- 📈 Look forward to meeting you in GitHub
- 🔭 I’m currently working on [Memocast](https://github.com/TankNee/Memocast), An awesome WizNote client

### 📊 Github State

![Github State](https://github-readme-stats.vercel.app/api?username=TankNee&show_icons=true&hide_border=true)

### 📶 Code State

![Code Srare](https://github-readme-stats.vercel.app/api/top-langs/?username=TankNee&layout=compact&hide_border=true&title_color=a0a9af)

### 🖥 Last Week Coding Time

<!--START_SECTION:waka-->
```text
No Activity tracked this Week
```
<!--END_SECTION:waka-->

### 📕 Blog

<!-- BLOG-POST-LIST:START -->
- [CS:APP Chapter 7 链接-读书笔记 - tanknee](http://www.cnblogs.com/tanknee/p/15323560.html)
- [CS:APP Chapter 6 存储器层次系统-读书笔记 - tanknee](http://www.cnblogs.com/tanknee/p/15323552.html)
- [CS:APP Chapter 5 程序优化-读书笔记 - tanknee](http://www.cnblogs.com/tanknee/p/15323528.html)
- [CS:APP Chapter 4 Y86-64处理器设计-读书笔记 - tanknee](http://www.cnblogs.com/tanknee/p/15322302.html)
- [CS:APP Chapter 3 程序的机器级表示-读书笔记 - tanknee](http://www.cnblogs.com/tanknee/p/15322287.html)
<!-- BLOG-POST-LIST:END -->
